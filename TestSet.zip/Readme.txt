
i) There are four kinds of test & congestion coefficient sets in the directories, such as "NoCongestion", "MONCongestion", "WEDCongestion", and "SUNCongestion" .

ii) Each set contains 8 variables, the meaning of them is listed as follows:
a. TaskSet: It is a good information matrix. The first two columns are the longitude and latitude of customers and depots, the third column is depot code of goods ( 0 represents the first two column is the longitude and latitude of this depot), and the fourth column is the arrival time slice of goods.
b. CongestionCoefficientSet: It is a cell variable which has 13 cells. These 13 cells represent the traffic condition in 7:00-8:00, 8:00-9 :00, 9:00-10:00, 10:00-11:00, 11:00-12:00, 12:00-13:00, 13:00-14:00, 14:00-15:00, 15:00-16:00, 16:00-17:00, 17:00-18:00, 18:00-19:00, 19:00-7:00, respectively. Every cell is a matrix that represents the congestion coefficients between customers or depots. 
c. Distance: It is a distance matrix which contains the distance between customers or depots in this testset. 
d. NT: The number of tasks.
e. ND: The number of depots.
f. NV: The number of vehicles.
g. InitialLocationofVehicle: The initial location of vehicles.
h. InitialSpeed: Initial vehicle speed.

